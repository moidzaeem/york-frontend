'use client'

import Card from '@/components/card/Card';
import Label from '@/components/Label';
import Input from '@/components/Input';
import SidebarTools from '@/components/icons/SidebarTools';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useAccessControl } from '@/hooks/accessControl';


const Page = () => {

    // const {isSubmitted, submitData} = useSubmitData('/api/logistics/create');
    // const {dropdowns} = useFetchDropdownData("/api/dropdowns/logistic");

    const [input, setInput] = useState({
        name: "",
        value: "",
    });

    const [form, setForm] = useState({
        milimeter: 0,
        centimeter: 0,
        meter: 0,
        inch: 0,
        feet: 0,
    });
    const router = useRouter();
    const {permissions, can} = useAccessControl();

    if (!can("Converter")) {
        // navigate to 403 page.
        router.push(process.env.NEXT_PUBLIC_UNAUTHORIZED_ROUTE);
    }


    const handleInputChange = () => {

        event.preventDefault();

        let data = {};

        if (event.target.value !== "" &&  isNaN(parseFloat(event.target.value)))
            return false;

        setInput(prevState => {
            return {
                name: event.target.name,
                value: event.target.value,
            };
        });

        data = {
            milimeter: 0,
            centimeter: 0,
            meter: 0,
            inch: 0,
            feet: 0,
        };

        if (event.target.name == "milimeter") {

            if (event.target.value == "") {
                data = {
                    ...data,
                    [event.target.name]: event.target.value 
                }
            } 

            else
                data = convertFromMilimeter(event.target.value);
        }

        else if (event.target.name == "centimeter") {
            
            if (event.target.value == "") {
                data = {
                    ...data,
                    [event.target.name]: event.target.value 
                }
            } 

            else
                data = convertFromCentimeter(event.target.value);
        }

        else if (event.target.name == "meter") {
            
            if (event.target.value == "") {
                data = {
                    ...data,
                    [event.target.name]: event.target.value 
                }
            } 

            else
                data = convertFromMeter(event.target.value);
        }

        else if (event.target.name == "inch") {
            
            if (event.target.value == "") {
                data = {
                    ...data,
                    [event.target.name]: event.target.value 
                }
            } 

            else
                data = convertFromInch(event.target.value);
        }

        else if (event.target.name == "feet") {
            
            if (event.target.value == "") {
                data = {
                    ...data,
                    [event.target.name]: event.target.value 
                }
            } 

            else
                data = convertFromFeet(event.target.value);
        }

        setForm(prevState => {
            return {
                ...data
            };
        });
    }


    const handleConverter = () => {

        event.preventDefault();
        
        return false;
    }


    const convertFromMilimeter = (milimeterValue) => {
        return {
            milimeter: milimeterValue,
            centimeter: milimeterValue * 0.1,
            meter: milimeterValue * 0.001,
            inch: milimeterValue * 0.0393701,
            feet: milimeterValue * 0.00328084,
        };
    };

    const convertFromCentimeter = (centimeterValue) => {
        return {
            milimeter: centimeterValue * 10,
            centimeter: centimeterValue,
            meter: centimeterValue * 0.01,
            inch: centimeterValue * 0.393701,
            feet: centimeterValue * 0.0328084,
        };
    };

    const convertFromMeter = (meterValue) => {
        return {
            milimeter: meterValue * 1000,
            centimeter: meterValue * 100,
            meter: meterValue,
            inch: meterValue * 39.3701,
            feet: meterValue * 3.28084,
        };
    };

    const convertFromInch = (inchValue) => {
        return {
            milimeter: inchValue * 25.4,
            centimeter: inchValue * 2.54,
            meter: inchValue * 0.0254,
            inch: inchValue,
            feet: inchValue * 0.0833333,
        };
    };

    const convertFromFeet = (feetValue) => {
        return {
            milimeter: feetValue * 304.8,
            centimeter: feetValue * 30.48,
            meter: feetValue * 0.3048,
            inch: feetValue * 12,
            feet: feetValue,
        };
    };

    const breadcrumb = (
        <ul className="flex items-center justify-start gap-3">
            <li className="capitalize text-base text-gray-800 font-bold hover:text-blue-500 hover:underline cursor-pointer" >
                <Link href="/dashboard">Dashboard</Link>
            </li>
            <li >&gt;</li>
            <li className="capitalize text-base text-gray-500 font-bold">
                Converter
            </li>
        </ul>
    )

    return (
        <>
            <title>YORK - Converter</title>

            <Card className="h-auto min-h-96 md:rounded-[15px] bg-white md:bg-white px-0 md:px-4 dark:bg-transparent md:dark:bg-gray-800" >
                { breadcrumb }
                <div className="w-full flex flex-row gap-3 items-center justify-between px-4 my-8">
                    <div className="flex items-center justify-start gap-3 text-xl md:text-xl font-semibold">
                        <span className="size-[31px] rounded-full bg-[#f5f5f5] dark:bg-gray-900 inline-flex items-center justify-center">
                            <SidebarTools size="size-[23px] md:size-[23px]" className="fill-slate-800 dark:fill-slate-300" />
                        </span>
                        Converter
                    </div>
                </div>

                <div className="w-full px-4 mt-12">
                    <form onSubmit={handleConverter}>
                        <div className="grid grid-cols-1 gap-x-11 gap-y-6">

                            {/* Form Group start */}
                            <div className="">
                                <Label htmlFor="milimeter">
                                    Milimeter
                                </Label>
                                
                                <Input
                                    id="milimeter"
                                    type="number"
                                    name="milimeter"
                                    value={ form.milimeter }
                                    className="block mt-1 w-full bg-[#f5f5f5]"
                                    onChange={handleInputChange}
                                    />
                            </div>
                            {/* Form Group end */}

                            {/* Form Group start */}
                            <div className="">
                                <Label htmlFor="centimeter">
                                    Centimeter
                                </Label>
                                
                                <Input
                                    id="centimeter"
                                    type="number"
                                    name="centimeter"
                                    value={ form.centimeter }
                                    className="block mt-1 w-full bg-[#f5f5f5]"
                                    onChange={handleInputChange}
                                    />
                            </div>
                            {/* Form Group end */}

                            {/* Form Group start */}
                            <div className="">
                                <Label htmlFor="meter">
                                    Meter
                                </Label>
                                
                                <Input
                                    id="meter"
                                    type="number"
                                    name="meter"
                                    value={ form.meter }
                                    className="block mt-1 w-full bg-[#f5f5f5]"
                                    onChange={handleInputChange}
                                    />
                            </div>
                            {/* Form Group end */}

                            {/* Form Group start */}
                            <div className="">
                                <Label htmlFor="inch">
                                    Inch
                                </Label>
                                
                                <Input
                                    id="inch"
                                    type="number"
                                    name="inch"
                                    value={ form.inch }
                                    className="block mt-1 w-full bg-[#f5f5f5]"
                                    onChange={handleInputChange}
                                    />
                            </div>
                            {/* Form Group end */}

                            {/* Form Group start */}
                            <div className="">
                                <Label htmlFor="feet">
                                    Feet
                                </Label>
                                
                                <Input
                                    id="feet"
                                    type="number"
                                    name="feet"
                                    value={ form.feet }
                                    className="block mt-1 w-full bg-[#f5f5f5]"
                                    onChange={handleInputChange}
                                    />
                            </div>
                            {/* Form Group end */}
                        </div>

                        {/* <BaseButton type="submit" className="!bg-[#13ad86] text-xs text-white md:text-base" >
                            Convert
                        </BaseButton> */}
                    </form>
                </div>
            </Card>
        </>
    )
}

export default Page;