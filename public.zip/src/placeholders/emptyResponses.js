export const datatableResponse = {
    data: [],
    links: {
        first: "",
        last: "",
        prev: "",
        next: ""
    },
    meta: {
        current_page: 1,
        last_page: 1,
        path: "",
        per_page: 10,
        from: 0,
        to: 0,
        total: 0
    }
};